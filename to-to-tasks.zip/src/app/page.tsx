import MainToDoList from "@/components/MainToDoList";
import React from "react";

function Home() {
	return (
		<>
			<MainToDoList />
		</>
	);
}

export default Home;
